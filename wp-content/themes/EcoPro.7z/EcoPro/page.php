<?php 

	get_header();
		include(THEME_LIB.'/_spotlight.php');
		include(THEME_LIB.'/_sub_head.php');
		include (THEME_LIB . '/template_page.php');
	get_footer(); 
?>
