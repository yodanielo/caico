<div class="postwrap">	
<div class="hentry">		
	<div class="copy"> <?php comments_template();?></div>
</div>
<br/>
</div>