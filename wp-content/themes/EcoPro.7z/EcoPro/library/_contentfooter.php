<div class="hl"></div>
<div class="post-footer pfooterdark">

		<div class="right">
			<span><a href="#header"><?php _e('Go To Top &raquo;', TDOMAIN);?></a></span></div>
	<div class="clear"></div>

</div>
<div class="hl2"></div>