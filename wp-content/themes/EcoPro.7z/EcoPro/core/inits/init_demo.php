<link rel="stylesheet" href="<?php echo CORE_CSS.'/pick.css';?>" type="text/css" media="screen" />
