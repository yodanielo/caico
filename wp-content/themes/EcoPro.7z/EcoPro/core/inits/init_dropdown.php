<link rel="stylesheet" href="<?php echo PRO_CSS.'/dropdown.css';?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo CORE_JS;?>/dropdown.js"></script>